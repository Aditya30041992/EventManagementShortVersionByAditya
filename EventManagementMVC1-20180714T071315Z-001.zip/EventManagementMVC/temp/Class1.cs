﻿using System;

namespace temp
{
    public class Class1
    {
    }
}
