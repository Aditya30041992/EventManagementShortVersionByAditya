﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BOL
{
    public class FlowerDetails
    {

        public string FlowerId { get; set; }
        public string FlowerName { get; set; }
        //public string FlowerFileName { get; set; }
        //public string FlowerFilePath { get; set; }
        public int FlowerCost { get; set; }
     //   public String FlowerCreatedBy { get; set; }

    }
}