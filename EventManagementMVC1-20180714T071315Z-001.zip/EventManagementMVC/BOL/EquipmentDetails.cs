﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BOL
{
    public class EquipmentDetails
    {
        public string EquipmentId { get; set; }
        public string EquipmentName { get; set; }
        //public string EquipmentFileName { get; set; }
        //public string EquipmentFilePath { get; set; }
        public int EquipmentCost { get; set; }
        //public string EquipmentCreatedBy { get; set; }
    }
}