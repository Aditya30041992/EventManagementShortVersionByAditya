﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BOL
{
    public class LightDetails
    {
        public string LightId { get; set; }
        //public string LightType { get; set; }
        public string LightName { get; set; }
        //public string LightFileName { get; set; }
        //public string LightFilePath { get; set; }
        public int LightCost { get; set; }
       // public string LightCreatedBy { get; set; }

    }
}